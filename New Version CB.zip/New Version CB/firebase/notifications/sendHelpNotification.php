<?php

// driverID and carID used to identify the driver who needs help and his car
function sendNotification($firebase_token,$title,$message,$driverID,$carID,$problemID){
    $firebase_api = "AAAAc98AAxw:APA91bHX0_sWe3FCB2Tfd8U05140UgVidElNhbxJetCM2wdyuKIKH6Q8ct2cXGdBMWICAaGM75lHZQWgiIFVgOG6-PANIO948Kz5lb9DV2jW4-mQqNTJsH31JEMg1dLZT-_U-7rVT9jl";
    
    
    require_once __DIR__ . '/notification.php';
	$notification = new Notification();
	
	$notification->setTitle($title);
	$notification->setMessage($message);
	$notification->setToCarID($carID);
	$notification->setToDriverID($driverID);
	$notification->setProblemID($problemID);
	$notification->setNotificationType("HELP");
	
	$requestData = $notification->getNotificatin();
	$fields = array(
								'to' => $firebase_token,
								'data' => $requestData,
							);
		
						// Set POST variables
						$url = 'https://fcm.googleapis.com/fcm/send';
 
						$headers = array(
							'Authorization: key=' . $firebase_api,
							'Content-Type: application/json'
						);
						
						// Open connection
						$ch = curl_init();
 
						// Set the url, number of POST vars, POST data
						curl_setopt($ch, CURLOPT_URL, $url);
 
						curl_setopt($ch, CURLOPT_POST, true);
						curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 
						// Disabling SSL Certificate support temporarily
						curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
 
						curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
						$result = curl_exec($ch);
						if($result === FALSE){
						    
							die('Curl failed: ' . curl_error($ch));
						}
						
						curl_close($ch);
						
					return $fields;
	
    
}

?>