<?php
class CBNotification{
	private $title;
	private $message;
	private $image_url;
	private $action;
	private $action_destination;
	private $data;
	private $toPersonID;
//	private $toCarID;
	private $carID;
	private $notificationType;
	
	function __construct(){
         
	}
 
	public function setTitle($title){
		$this->title = $title;
	}
 
    public function setToPerson($toPersonID){
		$this->toPersonID = $toPersonID;
	}
		public function setNotificationType($notificationType){
		$this->notificationType = $notificationType;
	}
 
	
	/*public function setToCarID($toCarID){
		$this->toCarID = $toCarID;
	}*/
	public function setMessage($message){
		$this->message = $message;
	}
 
	public function setImage($imageUrl){
		$this->image_url = $imageUrl;
	}
 
	public function setAction($action){
		$this->action = $action;
	}
 
	public function setActionDestination($actionDestination){
		$this->action_destination = $actionDestination;
	}
 
	public function setPayload($data){
		$this->data = $data;
	}
	public function setCarID($carID){
	    $this->carID=$carID;
	}
	
	public function getNotificatin(){
		$notification = array();
		$notification['title'] = $this->title;
		$notification['message'] = $this->message;
		$notification['image'] = $this->image_url;
		$notification['action'] = $this->action;
		$notification['action_destination'] = $this->action_destination;
		$notification['toPersonID']=$this->toPersonID; //toUserID
	//	$notification['toCarID']=$this->toCarID;
		$notification['carID']=$this->carID;
		$notification['notificationType']=$this->notificationType;
		return $notification;
	}
}
?>