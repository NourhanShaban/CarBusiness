<?php
require "../../includes/CBDbOperations.php";
require "../../firebase/notifications/sendCBNotification.php";

$db = new DbOperations(); 
$ret=array();
	$firebase_token=$db->getCBToken($_POST['carid'])['CBToken'];
	$toPerson=$db->getToPerson($firebase_token)['ID'];
//	$firebase_token=$_POST["token"];
	


					if(isset($_POST['userid']) and
					   isset($_POST['title']) and
					   isset($_POST['message'] )and
					   isset($_POST['carid'])){
					       
					       $userResult=sendNotification($firebase_token,$_POST['title'],$_POST['message'],$toPerson,$_POST['carid']);
		
						require_once __DIR__ . '/CBNotification.php';
						$notification = new CBNotification();
	
						$title = $_POST['title'];
						$message = isset($_POST['message'])?$_POST['message']:'';
						
						$notification->setTitle($title);
						$notification->setMessage($message);
						$notification->setCarID($_POST['carid']);
						$notification->setToPerson($_POST['userid']);
						$notification->setNotificationType("CB");
						
				 $firebase_api="AAAAI8suOo0:APA91bGZToCLASFsc31TeQUkf2djwubaxLtfWdf0EjvyeX9Jfe9sWFEf9Io0VFvBmHkM4nO3kU8mEcRGPscWw2Eu_swNtWjBCNR27rhjxgciQ2hquR-B0BdmO54uamfP6Lvsk3O51GIqvYsHwwlduaVt-Uv2UWOALQ";		
                // $firebase_api = "AAAAc98AAxw:APA91bHX0_sWe3FCB2Tfd8U05140UgVidElNhbxJetCM2wdyuKIKH6Q8ct2cXGdBMWICAaGM75lHZQWgiIFVgOG6-PANIO948Kz5lb9DV2jW4-mQqNTJsH31JEMg1dLZT-_U-7rVT9jl";
                 $ret["api"]= $firebase_api;
                 $ret["token"]=$firebase_token;
						
						//$topic = $_POST['topic'];
						
						$requestData = $notification->getNotificatin();
						
						
		
	           	$fields = array(
								'to' => $firebase_token,
								'data' => $requestData,
							);
		
						// Set POST variables
						$url = 'https://fcm.googleapis.com/fcm/send';
 
						$headers = array(
							'Authorization: key=' . $firebase_api,
							'Content-Type: application/json'
						);
						
						// Open connection
						$ch = curl_init();
 
						// Set the url, number of POST vars, POST data
						curl_setopt($ch, CURLOPT_URL, $url);
 
						curl_setopt($ch, CURLOPT_POST, true);
						curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 
						// Disabling SSL Certificate support temporarily
						curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
 
						curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
 
						// Execute post
						$result = curl_exec($ch);
						$ret['fields']=$fields;
						$ret["error"]=false;
						if($result === FALSE){
						    $ret["uns"]=1;
							die('Curl failed: ' . curl_error($ch));
						}else{
						    $ret["uns"]=2;
						}
						$ret["result"]=$result;
 
						// Close connection
						curl_close($ch);
						
						echo json_encode($ret,JSON_PRETTY_PRINT);
						
						
					}else{
					    
					    $ret["error"]=true;
					    $ret["message"]="required Field missing";
					    $ret["token"]=$firebase_token;
					    echo json_encode($rets,JSON_PRETTY_PRINT);
					}
	
					?>