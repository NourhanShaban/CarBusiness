<?php

// driverID and carID used to identify the driver who needs help and his car
function sendNotification($firebase_token,$title,$message,$personID,$carID){
    $firebase_api = "AAAAI8suOo0:APA91bGZToCLASFsc31TeQUkf2djwubaxLtfWdf0EjvyeX9Jfe9sWFEf9Io0VFvBmHkM4nO3kU8mEcRGPscWw2Eu_swNtWjBCNR27rhjxgciQ2hquR-B0BdmO54uamfP6Lvsk3O51GIqvYsHwwlduaVt-Uv2UWOALQ";
    
    
    require_once __DIR__ . '/CBNotification.php';
	$notification = new CBNotification();
	
	$notification->setTitle($title);
	$notification->setMessage($message);
	//$notification->setToCarID($carID);
	$notification->setToPerson($personID);
	$notification->setCarID($carID);
	$notification->setNotificationType("CB");
	$requestData = $notification->getNotificatin();
	$fields = array(
								'to' => $firebase_token,
								'data' => $requestData
							);
		
						// Set POST variables
						$url = 'https://fcm.googleapis.com/fcm/send';
 
						$headers = array(
							'Authorization: key=' . $firebase_api,
							'Content-Type: application/json'
						);
						
						// Open connection
						$ch = curl_init();
 
						// Set the url, number of POST vars, POST data
						curl_setopt($ch, CURLOPT_URL, $url);
 
						curl_setopt($ch, CURLOPT_POST, true);
						curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 
						// Disabling SSL Certificate support temporarily
						curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
 
						curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
						$result = curl_exec($ch);
						if($result === FALSE){
						    
							die('Curl failed: ' . curl_error($ch));
						}
						
						curl_close($ch);
						
					return json_encode($fields);
	
    
}
sendNotification("dFRb-ANx7qY:APA91bEf39-5YN8MPSyirD5VGtmwNMUkWj563GNcgb86ZCrP9kXf9YYlrt9a-zapQ-5jagzujVkrj8oh_6KISaPlOrNue0tNJB2H8UwfKQwKvy79xJncZnGSf2oQqauhfm23bwziCLC_yJdwAKKhswvnKy5k70cAgQ","title","msff",12,14);

?>