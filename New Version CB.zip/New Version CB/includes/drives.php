<?php

require_once dirname(__FILE__) ."/DBConnection.php";



     function createCarDriverRelation($userID,$carID){
         
         $db=new DbConnect();
         $con=$db->connect();
    
    	$stmt =$con->prepare("INSERT INTO `drives` (`carID`, `driverID`, `isOwner`) VALUES (?, ?,DEFAULT );");
	    $stmt->bind_param("ii",$carID,$userID);
	    
	    if($stmt->execute()){
                    $stmt->store_result();
                    $resultID=$con->insert_id;
                    $stmt->free_result();
                    $stmt->close();
                    
                    return 1;
        
				}else{
				    return 0;
				}
    
  }

?>