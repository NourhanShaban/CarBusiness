<?php 

	class CarOperations{

		private $con; 

		function __construct(){

			require_once dirname(__FILE__) ."/DBConnection.php";

			$db = new DbConnect();

			$this->con = $db->connect();

		}

		/*CRUD -> C -> CREATE */

		public function createCarProfile($CarModel,$CarSerial){
            $resultID=$this->isCarExist($CarModel,$CarSerial);
            $resultJSON=array();
			if($resultID){
                $resultJSON["return"]=0;
                $resultJSON["carID"]=$resultID;
				return $resultJSON; 
			}else{
			     //$objRet=array();
				
				$stmt = $this->con->prepare("INSERT INTO `cars` (`carID`, `model`, `CarSerial`) VALUES (NULL, ?, ?);");
				$stmt->bind_param("ss",$CarModel,$CarSerial);

				if($stmt->execute()){
                    $stmt->store_result(); 
                    //$result=$stmt->bind_result($locationID,$latitude_ret,$longitude_ret,$altitude_ret);
                    $resultID=$this->con->insert_id;
                    
                    $stmt->free_result();
                    $stmt->close();
                    $resultJSON["return"]=1;
                    $resultJSON["carID"]=$resultID;
				    return $resultJSON ; 
                    
				   
				}else{
				    $resultJSON["return"]=-1;
                    $resultJSON["userID"]=-1;
				    return $resultJSON ; 
				}
			//}
		  }
        }
		
		private function isCarExist($CarModel,$CarSerial){
			$stmt = $this->con->prepare("SELECT `carID` FROM `car` WHERE `model` = ? AND `CarSerial` = ?");
			$stmt->bind_param("ss",$CarModel,$CarSerial);
			$stmt->execute(); 
			$stmt->store_result(); 
            
            $result=$stmt->bind_result($carID);
            $resultID=0;
            while($stmt->fetch()){
                $resultID=$carID;
            }
                $stmt->free_result();
                    $stmt->close();
			return $resultID;
			
		}

	}
	
	?>