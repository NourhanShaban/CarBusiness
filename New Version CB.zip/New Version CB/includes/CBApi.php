<?php 
 
 //database constants


define('DB_HOST', 'localhost');
define('DB_USER','id4810695_asnasucse18');
define('DB_PASS', 'asn_asu_cse18');
define('DB_NAME', 'id4810695_asn_asu_cse18');

 
 //connecting to database and getting the connection object
 $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
 
 //Checking if any error occured while connecting
 if (mysqli_connect_errno()) {
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
 die();
 }
 
 
 if($_SERVER['REQUEST_METHOD']=='POST'){
    
	if( isset($_POST['personID']) )	{
	    
	     $personID=$_POST['personID'];
 
 
 
        //creating a query
        $stmt = $conn->prepare("SELECT carID, model, price,userName,phonenumber FROM CarServices1 , drivers WHERE ID=ownerID AND SoldBoughtFlag=0 ;");    //AND ownerID <>$personID
        
        
 
       //executing the query 
       $stmt->execute();
 
       //binding results to the query 
       $stmt->bind_result($carID, $model, $price, $userName,$phonenumber);
 
       $products = array(); 
 
      //traversing through all the result 
      while($stmt->fetch()){
         $temp = array();
         $temp['carID'] = $carID; 
         $temp['model'] = $model; 
         $temp['price'] = $price; 
        //$temp['status'] = $status; 
       //$temp['SoldBoughtFlag'] = $SoldBoughtFlag; 
      // $temp['ownerID'] = $ownerID; 
        $temp['userName'] = $userName; 
        $temp['phonenumber'] = $phonenumber;
        array_push($products, $temp);
      }
 
      //displaying the result in json format 
       echo json_encode($products);
	}
 
 	else{
		$temp['error'] = true; 
		$temp['message'] = "Doesn't receive personID";
	}
}else{
	$temp['error'] = true; 
	$temp['message'] = "Invalid Request";
}
echo json_encode($temp);

?>
	