<?php 

	class ProblemOperations{

		private $con; 

		function __construct(){

			require_once dirname(__FILE__) ."/DBConnection.php";

			$db = new DbConnect();

			$this->con = $db->connect();

		}

		/*CRUD -> C -> CREATE */

		public function createProblem($type, $time, $location,$message){
          
			
			 $resultJSON=array();
				$stmt = $this->con->prepare("INSERT INTO `driverProblem` (`problemID`, `type`,`message`, `time`, `location`) VALUES (NULL, ?, ?, ?,?);");
				$stmt->bind_param("ssss",$type,$message,$time,$location);

				if($stmt->execute()){
                    $stmt->store_result();
                    $resultID=$this->con->insert_id;
                    
                    $stmt->free_result();
                    $stmt->close();
                    $resultJSON["return"]=1;
                    $resultJSON["problemID"]=$resultID;
				    return $resultJSON ; 
			       
					
				}else{
					$resultJSON["return"]=-1;
                    $resultJSON["userID"]=-1;
				    return $resultJSON ;  
				}
			}
			
			
			
		public function bindProblemDriverCar($carID,$driverID,$problemID){
			    $returnJSON=array();
			    $returnJSON["carID"]=$carID;
			    $returnJSON["driverID"]=$driverID;
			    $returnJSON["pbID"]=$problemID;
			    $returnJSON["con"]=$this->con==null;
                $stmt = $this->con->prepare("INSERT INTO `reportProblem` (`carID`, `driverID`, `problemID`) VALUES (?, ?, ?);");
				$stmt->bind_param("iii",$carID,$driverID,$problemID);
            if($stmt->execute()){
                $returnJSON["return"]=1;
                return $returnJSON;
            }else{
                $returnJSON["return"]=0;
                return $returnJSON;
            }
            
        }
        
        //search for neighbours and send push notification to help
		
		
}