<?php 

	class DbOperations{

		private $con; 

		function __construct(){

			require_once dirname(__FILE__) ."/DBConnection.php";

			$db = new DbConnect();

			$this->con = $db->connect();

		}

		/*CRUD -> C -> CREATE */

		public function createUser($userName, $email, $password,$phonenumber,$token){
            $resultID=$this->isUserExist($userName,$email);
            $resultJSON=array();
			if($resultID){
                $resultJSON["return"]=0;
                $resultJSON["userID"]=$resultID;
				return $resultJSON ; 
			}else{
				$password = md5($password);
				$stmt = $this->con->prepare("INSERT INTO `drivers` (`ID`, `userName`, `email`, `password`,`phonenumber`,`token`) VALUES (NULL, ?, ?, ?, ?,?);");
				$stmt->bind_param("sssss",$userName,$email,$password,$phonenumber,$token);

				if($stmt->execute()){
                    $stmt->store_result(); 
                    //$result=$stmt->bind_result($locationID,$latitude_ret,$longitude_ret,$altitude_ret);
                    $resultID=$this->con->insert_id;
                    
                    $stmt->free_result();
                    $stmt->close();
                    $resultJSON["return"]=1;
                    $resultJSON["userID"]=$resultID;
				    return $resultJSON ; 
			        //return $resultID;
					
				}else{
					$resultJSON["return"]=-1;
                    $resultJSON["userID"]=-1;
				    return $resultJSON ;  
				}
			}
		}
		
		public function createSCRelation($carID, $serviceCenterID, $maintenanaceTime){
            
				$stmt = $this->con->prepare("INSERT INTO `needMaintenance` (`carID`, `serviceCenterID`, `maintenanaceTime`) VALUES (?, ?, ?);");
				$stmt->bind_param("iis",$carID,$serviceCenterID,$maintenanaceTime);//
				
				if($stmt->execute()){
                        $stmt->store_result(); 
                    //$result=$stmt->bind_result($locationID,$latitude_ret,$longitude_ret,$altitude_ret);
                        $resultID=$this->con->insert_id;
                    
                        $stmt->free_result();
                        $stmt->close();
                        $resultJSON["return"]=1;
				        return $resultJSON ; 
			        //return $resultID;
					
				   }else{
					  $resultJSON["return"]=-1;
				      return $resultJSON ;  
				}

				
		}
		
			public function insertOBDData($VehicleIdentificationNumberVIN, 
			                              $ControlModulePowerSupply, 
                                          $TimingAdvance,
                                          $CommandEquivalenceRatio,
                                          $DistancetraveledwithMILon,
                                          $TimerunwithMILon, 
                                          $Distancesincecodescleared, 
			                              $Timesincetroublecodescleared,
                                          $EngineRPM,
                                          $EngineRuntime,
                                          $Engineoiltemperature,
                                          $ThrottlePosition,
                                          $EngineLoad,
			                              $Absoluteload, 
                                          $MassAirFlow,
                                          $FuelInjectionTiming,
                                          $RelativeAccPedalPos,
                                          $FuelLevel, 
                                          $FuelType, 
			                              $FuelConsumptionRate,
                                          $AirFuelRatio,
                                          $LongTermFuelTrimBank1,
                                          $LongTermFuelTrimBank2,
                                          $ShortTermFuelTrimBank1,
                                          $ShortTermFuelTrimBank2,
                                          $WidebandAirFuelRatio,
                                          $FuelPressure,
			                              $FuelRailPressure,
                                          $BarometricPressure,
                                          $IntakeManifoldPressure,
                                          $Absoluteevapsystemvaporpressure,
                                          $Evaporationsystemvaporpressure,
                                          $EngineCoolantTemperature,
			                              $AirIntakeTemperature,
                                          $CatalystTemperatureBank1Sensor1,
                                          $CatalystTemperatureBank2Sensor1,
                                          $CatalystTemperatureBank1Sensor2,
                                          $CatalystTemperatureBank2Sensor2,
                                          $AmbientAirTemperature,
                                          $VehicleSpeed,
			                              $hypridBatteryremainlife, 
                                          $ActualEnginePercentTorque,
                                          $DriversdemandengineTourque,
                                          $EnginerefrenceTourque,
                                          $EvaporativePurge,
                                          $CommandedEGR,
			                              $EGRerror,
                                          $EthanolPercentage,
                                          $DiagnosticTroubleCodes,
                                          $TroubleCodes,
                                          $PendingTroubleCodes,
                                          $PermanentTroubleCodes){
           
			$stmt = $this->con->prepare("INSERT INTO `obdii` (`Oid`, `VehicleIdentificationNumberVIN`, 
			                              `ControlModulePowerSupply`, 
                                          `TimingAdvance`,
                                          `CommandEquivalenceRatio`,
                                          `DistancetraveledwithMILon`,
                                          `TimerunwithMILon`, 
                                          `Distancesincecodescleared`, 
			                              `Timesincetroublecodescleared`,
                                          `EngineRPM`,
                                          `EngineRuntime`,
                                          `Engineoiltemperature`,
                                          `ThrottlePosition`,
                                          `EngineLoad`,
			                              `Absoluteload`, 
                                          `MassAirFlow`,
                                          `FuelInjectionTiming`,
                                          `RelativeAccPedalPos`,
                                          `FuelLevel`, 
                                          `FuelType`, 
			                              `FuelConsumptionRate`,
                                          `AirFuelRatio`,
                                          `LongTermFuelTrimBank1`,
                                          `LongTermFuelTrimBank2`,
                                          `ShortTermFuelTrimBank1`,
                                          `ShortTermFuelTrimBank2`,
                                          `WidebandAirFuelRatio`,
                                          `FuelPressure`,
			                              `FuelRailPressure`,
                                          `BarometricPressure`,
                                          `IntakeManifoldPressure`,
                                          `Absoluteevapsystemvaporpressure`,
                                          `Evaporationsystemvaporpressure`,
                                          `EngineCoolantTemperature`,
			                              `AirIntakeTemperature`,
                                          `CatalystTemperatureBank1Sensor1`,
                                          `CatalystTemperatureBank2Sensor1`,
                                          `CatalystTemperatureBank1Sensor2`,
                                          `CatalystTemperatureBank2Sensor2`,
                                          `AmbientAirTemperature`,
                                          `VehicleSpeed`,
			                              `hypridBatteryremainlife`, 
                                          `ActualEnginePercentTorque`,
                                          `DriversdemandengineTourque`,
                                          `EnginerefrenceTourque`,
                                          `EvaporativePurge`,
                                          `CommandedEGR`,
			                              `EGRerror`,
                                          `EthanolPercentage`,
                                          `DiagnosticTroubleCodes`,
                                          `TroubleCodes`,
                                          `PendingTroubleCodes`,
                                          `PermanentTroubleCodes`) VALUES (NULL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);");
				$stmt->bind_param("ssssssssssssssssssssssssssssssssssssssssssssssssssss",$VehicleIdentificationNumberVIN,$ControlModulePowerSupply, 
                                          $TimingAdvance,
                                          $CommandEquivalenceRatio,
                                          $DistancetraveledwithMILon,
                                          $TimerunwithMILon, 
                                          $Distancesincecodescleared, 
			                              $Timesincetroublecodescleared,
                                          $EngineRPM,
                                          $EngineRuntime,
                                          $Engineoiltemperature,
                                          $ThrottlePosition,
                                          $EngineLoad,
			                              $Absoluteload, 
                                          $MassAirFlow,
                                          $FuelInjectionTiming,
                                          $RelativeAccPedalPos,
                                          $FuelLevel, 
                                          $FuelType, 
			                              $FuelConsumptionRate,
                                          $AirFuelRatio,
                                          $LongTermFuelTrimBank1,
                                          $LongTermFuelTrimBank2,
                                          $ShortTermFuelTrimBank1,
                                          $ShortTermFuelTrimBank2,
                                          $WidebandAirFuelRatio,
                                          $FuelPressure,
			                              $FuelRailPressure,
                                          $BarometricPressure,
                                          $IntakeManifoldPressure,
                                          $Absoluteevapsystemvaporpressure,
                                          $Evaporationsystemvaporpressure,
                                          $EngineCoolantTemperature,
			                              $AirIntakeTemperature,
                                          $CatalystTemperatureBank1Sensor1,
                                          $CatalystTemperatureBank2Sensor1,
                                          $CatalystTemperatureBank1Sensor2,
                                          $CatalystTemperatureBank2Sensor2,
                                          $AmbientAirTemperature,
                                          $VehicleSpeed,
			                              $hypridBatteryremainlife, 
                                          $ActualEnginePercentTorque,
                                          $DriversdemandengineTourque,
                                          $EnginerefrenceTourque,
                                          $EvaporativePurge,
                                          $CommandedEGR,
			                              $EGRerror,
                                          $EthanolPercentage,
                                          $DiagnosticTroubleCodes,
                                          $TroubleCodes,
                                          $PendingTroubleCodes,
                                          $PermanentTroubleCodes);
				
				
					if($stmt->execute()){
                        $stmt->store_result(); 
                    //$result=$stmt->bind_result($locationID,$latitude_ret,$longitude_ret,$altitude_ret);
                        $resultID=$this->con->insert_id;
                    
                        $stmt->free_result();
                        $stmt->close();
                        $resultJSON["return"]=1;
                        $resultJSON["Oid"]=$resultID;
				        return $resultJSON ; 
			        //return $resultID;
					
				   }else{
					  $resultJSON["return"]=-1;
                      $resultJSON["Oid"]=-1;
				      return $resultJSON ;  
				}
			}
		
		
		
		
		

		public function userLogin($email,$password){
			$password = md5($password);
			$stmt = $this->con->prepare("SELECT ID FROM drivers WHERE email = ? AND password = ?");
			$stmt->bind_param("ss",$email,$password);
			$stmt->execute();
			$stmt->store_result(); 
			$result=$stmt->bind_result($userID);
            $resultID=0;
            while($stmt->fetch()){
                $resultID=$userID;
            }
                /*$stmt->free_result();
                    $stmt->close();*/
			
		
			$this->setOnline($resultID);
			return $stmt->num_rows > 0; 
		}
		public function setOnline($id){
		    $stmt = $this->con->prepare("UPDATE drivers SET status='ONLINE' where ID = ? ");
		    $stmt->bind_param("i",$id);
			$stmt->execute();
			return $stmt->num_rows > 0; 
		}
        public function setOffline($id){
		    $stmt = $this->con->prepare("UPDATE drivers SET status='OFFLINE' where ID = ? ");
		    $stmt->bind_param("i",$id);
			$stmt->execute();
			return $stmt->num_rows > 0; 
		}
		
		public function setToken($id,$token){
		    $stmt = $this->con->prepare("UPDATE drivers SET token = ? where ID = ? ");
		    $stmt->bind_param("si",$token,$id);
			$stmt->execute();
			return $stmt->num_rows > 0; 
		}
		public function getToken($userID){
			$stmt = $this->con->prepare("SELECT token FROM drivers WHERE ID = ?");
			$stmt->bind_param("i",$userID);
			$stmt->execute();
			return $stmt->get_result()->fetch_assoc();
		}

		public function getUserByUsername($userName){
			$stmt = $this->con->prepare("SELECT * FROM drivers WHERE userName = ?");
			$stmt->bind_param("s",$userName);
			$stmt->execute();
			return $stmt->get_result()->fetch_assoc();
		}
		
		public function getUserByEmail($email){
			$stmt = $this->con->prepare("SELECT * FROM drivers WHERE email = ?");
			$stmt->bind_param("s",$email);
			$stmt->execute();
			return $stmt->get_result()->fetch_assoc();
		}
		
		public function getCarId($id){
			$stmt = $this->con->prepare("SELECT * FROM drives WHERE driverID = ?");
			$stmt->bind_param("i",$id);
			$stmt->execute();
			return $stmt->get_result()->fetch_assoc();
		}
		

		private function isUserExist($userName,$email){
			$stmt = $this->con->prepare("SELECT ID FROM drivers WHERE userName = ? OR email = ?");
			$stmt->bind_param("ss", $userName, $email);
			$stmt->execute(); 
			$stmt->store_result(); 
            
            $result=$stmt->bind_result($userID);
            $resultID=0;
            while($stmt->fetch()){
                $resultID=$userID;
            }
                $stmt->free_result();
                    $stmt->close();
			return $resultID;
			//return $stmt->num_rows > 0; 
		}
		
		

	}
	
	?>