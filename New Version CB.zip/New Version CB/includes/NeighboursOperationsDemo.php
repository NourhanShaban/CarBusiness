<?php 

	class NeighboursOperations{

		private $con; 

		function __construct(){

			require_once dirname(__FILE__) ."/DBConnection.php";
			require_once dirname(__FILE__) ."./../firebase/notifications/sendHelpNotification.php";

			$db = new DbConnect();

			$this->con = $db->connect();

		}
        
        public function retreiveNeighbours($userID,$latitude,$longitude,$altitude,$time,$title="title",$message="message",$help=false,$carID=null,$problemID=null,$loc=0.01,$ti=120){
            $resultJSON=array();
            $minLat=$latitude-$loc;
            $maxLat=$latitude+$loc;
            $minLong=$longitude-$loc;
            $maxLong=$longitude+$loc;
            
            $resultJSON["maxLat"]=$maxLat;
            $resultJSON["minLat"]=$minLat;
            $resultJSON["maxLong"]=$maxLong;
            $resultJSON["minLong"]=$minLong;
            
            
             $dtime = DateTime::createFromFormat('Y.m.d.H.i.s',$time);
             $dateFromDateTIME=$dtime->format('Y-m-d H:i:s');
           // $resultJSON["dtime"]=$dateFromDateTIME;
            
            $maxTime =  strtotime($dateFromDateTIME)+$ti;
            $minTime =  strtotime($dateFromDateTIME)-$ti;
            
            $maxTimeStr=date("Y-m-d H:i:s", $maxTime);
            $minTimeStr=date("Y-m-d H:i:s", $minTime);
            $resultJSON["maxTime"]=$maxTimeStr;
            $resultJSON["minTime"]=$minTimeStr;
            
            
            
            
            
    $stmt = $this->con->prepare("SELECT DISTINCT drivers.ID, drivers.userName,drivers.token, locations.latitude                                ,locations.longitude , locations.altitude 
                                        FROM drivers
                                        INNER JOIN goLocations ON drivers.ID = goLocations.driverID
                                        INNER JOIN locations ON locations.locationID = goLocations.locationID
                                        WHERE locations.latitude < ? and locations.latitude > ? 
                                        and locations.longitude < ? and locations.longitude > ? 
                                        and drivers.ID <> ?
                                        and drivers.status = 'ONLINE'
                                        and date(goLocations.time) between date(?) AND date(?)
                                        and time(goLocations.time) between time(?) AND time(?)");
                                        
            $stmt->bind_param("ddddissss",$maxLat,$minLat,$maxLong,$minLong,$userID,$minTimeStr,$maxTimeStr,$minTimeStr,$maxTimeStr);
            
            
           
            
            
            if($stmt->execute()){
                $resultJSON["return"]=1;
                $stmt->store_result();
                $result=$stmt->bind_result($driverID,$username,$token_,$latitude_,$longitude_,$altitude_/*,$time_*/);
                $count=0;
                $resultJSON["num_users"]=$stmt->num_rows;
                
                $usersJSON=array();
    
                while($stmt->fetch()){
                    $userResult=-1;
                    if($help){
                        $userResult=sendNotification($token_,$title,$message,$driverID,$carID,$problemID);
                    }
                    
                    
                    
                    $usersJSON["user".(string)$count]=array('driverID'=>$driverID,
                                        'driverName'=>$username,
                                       'latitude'=>$latitude_,
                                       'longitude'=>$longitude_,
                                       'altitude'=>$altitude_,
                                       //'time'=>$time_,
                                       'token'=>$token_,
                                       'notificationResult'=>$userResult);
                      
                                       
                                       
                    $count+=1;
                }
                $resultJSON["users"]=$usersJSON;
                
                $stmt->free_result();
                $stmt->close();
            }else{
                $resultJSON["return"]=0;
                
            }
            
			
            return $resultJSON;
            
            
        }
	}
        
        
?>