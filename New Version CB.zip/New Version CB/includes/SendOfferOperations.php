<?php 

	class SendOfferOperations{

		private $con; 

		function __construct(){

			require_once dirname(__FILE__) ."/DBConnection.php";

			$db = new DbConnect();

			$this->con = $db->connect();

		}
        
        
        public function sendOffer ($buyerID,$sellerID)
    {
            $resultJSON=array();
            $stmt = $this->con->prepare("UPDATE reportProblem SET acceptorID=? where problemID = ? ");
		    $stmt->bind_param("ii",$driverID,$problemID);
			$stmt->execute();
            $stmt = $this->con->prepare("SELECT drivers.*, locations.latitude, locations.longitude, locations.altitude, cars.CarSerial,driverProblem.type,driverProblem.message 
                                             FROM `drivers`, `locations`, `goLocations`, `cars`, `drives`,`driverProblem`
                                             WHERE drivers.ID = ? 
                                             AND driverProblem.problemID = ?
                                             AND goLocations.driverID = drivers.ID 
                                             AND locations.locationID = goLocations.locationID
                                             AND drives.driverID = drivers.ID                                 
                                             AND cars.carID = drives.carID;");
            $stmt->bind_param("ii",$to,$problemID);
            
                if($stmt->execute()){
                    $resultJSON["return"] = 1;
                    $stmt->store_result();
                    $result = $stmt->bind_result($ID, $username, $email, $password, $phone, $status, $token, $lat, $lng, $atit, $carnum,$type,$message);
                    $userinfoJSON=array();
                
                    while($stmt->fetch()){
                        $userinfoJSON = array(
                            "NeedHelpID" => $ID,
                            "username" => $username,
                            "phone" => $phone,
                            "position" => array(
                            "lat" => $lat,
                            "lng" => $lng,
                            "atit" => $atit),
                            "car_number" => $carnum,
                            "type" => $type,
                            "message" => $message
                        );
                    }

                    $resultJSON["need_help_info"] = $userinfoJSON;
                    $stmt->free_result();
                    $stmt->close();
                }
            
            else{
                $resultJSON["return"] = 0;
                $resultJSON["need_help_info"] = NULL;
            }

            return $resultJSON;
        }
    }
    ?>