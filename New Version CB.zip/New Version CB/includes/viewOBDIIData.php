<?php 
 
 //database constants


define('DB_HOST', 'localhost');
define('DB_USER','id4810695_asnasucse18');
define('DB_PASS', 'asn_asu_cse18');
define('DB_NAME', 'id4810695_asn_asu_cse18');

 
 //connecting to database and getting the connection object
 $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
 
 //Checking if any error occured while connecting
 if (mysqli_connect_errno()) {
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
 die();
 }
 
 //$response = array();
 
 if($_SERVER['REQUEST_METHOD']=='POST'){
     
	if( isset($_POST['carId'])){
	    
	      $carId=$_POST['carId'];
 
         //creating a query
          $stmt = $conn->prepare("SELECT carObd.carId,EngineCoolantTemperature,TroubleCodes ,LongTermFuelTrimBank1,IntakeManifoldPressure FROM obdii,carObd,CarServices1 WHERE Oid=obdID AND carObd.carId=CarServices1.carID AND carObd.carId=$carId ORDER BY Oid DESC LIMIT 1;");
 
         //executing the query 
          $stmt->execute();
          $stmt->store_result(); 
 
         //binding results to the query 
           $stmt->bind_result($carId, $EngineCoolantTemperature, $TroubleCodes, $LongTermFuelTrimBank1, $IntakeManifoldPressure);
 
           $products = array(); 
 
          //traversing through all the result 
         //while($stmt->fetch()){
           $stmt->fetch();
           $temp = array();
           $temp['carId'] = $carId; 
           $temp['EngineCoolantTemperature'] = $EngineCoolantTemperature; 
           $temp['TroubleCodes'] = $TroubleCodes; 
           $temp['LongTermFuelTrimBank1'] = $LongTermFuelTrimBank1; 
           $temp['IntakeManifoldPressure'] = $IntakeManifoldPressure; 
           
           
           
           
           if($EngineCoolantTemperature >= 90 and $EngineCoolantTemperature <= 104){
                     $temp['decisionEngineCoolantTemperature'] ="Normal"; 
              }else if($EngineCoolantTemperature < 90 or $EngineCoolantTemperature > 104 ){
                     $temp['decisionEngineCoolantTemperature'] ="Bad";
              }else{
                  
                  $temp['decisionEngineCoolantTemperature'] ="NULL";
                  
              }
              
              
               if($LongTermFuelTrimBank1 >= 5 and $LongTermFuelTrimBank1 <= 8){
                     $temp['decisionLongTermFuelTrimBank1'] ="Normal"; 
              }else if($LongTermFuelTrimBank1 >=-8 and $EngineCoolantTemperature <=-5  ){
                     $temp['decisionEngineCoolantTemperature'] ="Normal";
              }else if ($LongTermFuelTrimBank1 >= 10){
                     $temp['decisionLongTermFuelTrimBank1'] ="Bad";
                  
              }else if ($LongTermFuelTrimBank1 >=20 and $LongTermFuelTrimBank1 <=25){
                     $temp['decisionLongTermFuelTrimBank1'] ="VeryBad";
                  
              }else if ($LongTermFuelTrimBank1 >=-20 and $LongTermFuelTrimBank1 <=-25){
                     $temp['decisionLongTermFuelTrimBank1'] ="VeryBad";
                  
              }else{
                  
                  $temp['decisionLongTermFuelTrimBank1'] ="NULL";
                  
              }
              
              
              if($IntakeManifoldPressure >= 0 and $IntakeManifoldPressure <= 74.5){
                     $temp['decisionIntakeManifoldPressure'] ="Normal"; 
              }else if($IntakeManifoldPressure >=54.18 and $IntakeManifoldPressure >=67.7 ){
                     $temp['decisionIntakeManifoldPressure'] ="Engine Not Running";
              }else{
                  
                  $temp['decisionIntakeManifoldPressure'] ="NULL";
                  
              }
         
           array_push($products, $temp);
         //}
 
          //displaying the result in json format 
          echo json_encode($products);
	}
 
 	else{
		$temp['error'] = true; 
		$temp['message'] = "Doesn't receive carID";
	}
}else{
	$temp['error'] = true; 
	$temp['message'] = "Invalid Request";
}
echo json_encode($temp);

?>