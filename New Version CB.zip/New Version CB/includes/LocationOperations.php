<?php 

	class LocationOperations{

		private $con; 

		function __construct(){

			require_once dirname(__FILE__) ."/DBConnection.php";

			$db = new DbConnect();

			$this->con = $db->connect();

		}

		/*CRUD -> C -> CREATE */

		public function createLocation($latitude,$longitude,$altitude){
            $result=$this->isLocationExist($latitude,$longitude,$altitude);
			if($result >0){// location already found
                return $result;
			}else{
				
				$stmt = $this->con->prepare("INSERT INTO `locations` (`locationID`, `latitude`, `longitude`, `altitude`) VALUES (NULL, ?, ?, ?);");
				$stmt->bind_param("ddd",$latitude,$longitude,$altitude);
                
                    

				if($stmt->execute()){
                    $stmt->store_result(); 
                    //$result=$stmt->bind_result($locationID,$latitude_ret,$longitude_ret,$altitude_ret);
                    $resultID=$this->con->insert_id;
                    /*while($row=$stmt->fetch()){
                        $resultID=$row["locationID"];
                    }*/
                    $stmt->free_result();
                    $stmt->close();
			        return $resultID;
                   // return 1;
				}else{
					return -1;
				}
			}
		}

        public function bindLocationDriverCar($locationID,$userID,$carID,$locationTime){
            $stmt = $this->con->prepare("INSERT INTO `goLocations` (`locationID`, `carID`, `driverID`, `time`) VALUES (?, ?, ?, ?);");
				$stmt->bind_param("iiis",$locationID,$carID,$userID,$locationTime);
            if($stmt->execute()){
                return 1;
            }else{
                return 0;
            }
            
        }
		

		private function isLocationExist($latitude,$longitude,$altitude){
            $response=array();
			$stmt = $this->con->prepare("SELECT locationID ,latitude , longitude , altitude FROM locations WHERE latitude = ? AND longitude = ? AND altitude = ?");
			$stmt->bind_param("ddd", $latitude,$longitude,$altitude);
			$stmt->execute(); 
			$stmt->store_result(); 
			//if($stmt->num_rows >0)
			
            /*$result = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            return $result["locationID"];*/
            
            $result=$stmt->bind_result($locationID,$latitude_ret,$longitude_ret,$altitude_ret);
            $resultID=0;
            while($stmt->fetch()){
                $resultID=$locationID;
            }
                $stmt->free_result();
                    $stmt->close();
			return $resultID;
            
		}
        
        
        
        

	}
	
	?>