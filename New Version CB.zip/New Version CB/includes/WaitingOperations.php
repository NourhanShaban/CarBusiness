<?php
    class WaitingOperations {
        private $con; 

		function __construct(){

			require_once dirname(__FILE__) ."/DBConnection.php";

			$db = new DbConnect();

			$this->con = $db->connect();

        }
        
        public function getVolunteer($problemID)
        {
            $resultJSON=array();
            
            $acceptorID = waitForAcceptor($problemID);
            
            if($acceptorID){
                $stmt = $this->con->prepare("SELECT drivers.*, locations.latitude, locations.longitude, locations.altitude 
                                             FROM `drivers`, `locations`, `goLocations` 
                                             WHERE drivers.ID = ? 
                                             AND goLocations.driverID = drivers.ID 
                                             AND locations.locationID = goLocations.locationID
                                             ORDER BY goLocations.time DESC LIMIT 1;");
                $stmt->bind_param("i",$acceptorID);
            
                if($stmt->execute()){
                    $resultJSON["return"] = 1;
                    $stmt->store_result();
                    $result = $stmt->bind_result($ID, $username, $email, $password, $phone, $status, $token, $lat, $lng, $atit);
                    $userinfoJSON=array();
                
                    while($stmt->fetch()){
                        $userinfoJSON = array(
                            "acceptorID" => $ID,
                            "username" => $username,
                            "phone" => $phone,
                            "position" => array(
                                "lat" => $lat,
                                "lng" => $lng,
                                "atit" => $atit
                            )
                        );
                    }

                    $resultJSON["acceptor_info"] = $userinfoJSON;
                    $stmt->free_result();
                    $stmt->close();
                }
            }
            else{
                $resultJSON["return"] = 0;
                $resultJSON["acceptor_info"] = NULL;
            }

            return $resultJSON;
        }

        function waitForAcceptor($problemID){
            ini_set('max_execution_time', 300); //300 seconds = 5 minutes
            
            $acceptorFound = false;

            $stmt = $this->con->prepare("SELECT acceptorID
                                         FROM `reportProblem`
                                         WHERE problemID = ?");
            $stmt->bind_param("i",$problemID);

            $timePin = getdate();
            while((getdate()[minutes] - $timePin[minutes]) < 3){
                if($stmt->execute()){
                    $resultJSON["return"] = 1;
                    $stmt->store_result();
                    $result = $stmt->bind_result($ID);
                
                    while($stmt->fetch()){
                        $acceptorID = $ID;
                    }
                    if($acceptorID){
                        $acceptorFound = true;
                        break;
                    }
                }
                // echo (getdate()[minutes] - $timePin[minutes]);
            }
            return $acceptorID;
        }

    }

?>