
<?php 

class Advoperations{

    private $con; 

    function __construct(){

        require_once dirname(__FILE__) ."/DBConnection.php";

        $db = new DbConnect();

        $this->con = $db->connect();

    }

    


    public function createAdvertiser($name,$slogan,$serviceType,$adrs,$workingTime,$phone,$email,$licence,$icon,$iconName,$lat,$lng,$atit,$password,$cc){
        $resultID=$this->isUserExist($name,$email);
        $resultJSON=array();
        if($resultID){
            $resultJSON["return"]=0;
            $resultJSON["userID"]=$resultID;
            return $resultJSON ; 
        }else{
            $mainURL = 'https://asnasucse18.000webhostapp.com/Android/includes/Pictures/';
            $jpg = '.jpg';
            $specificURL = $mainURL.$iconName.$email.$jpg;
            $password = md5($password);
            $decodedimage = base64_decode("$icon");
            file_put_contents("/storage/ssd3/695/4810695/public_html/Android/includes/Pictures/" . $iconName.$email . ".jpg", $decodedimage);
            $stmt = $this->con->prepare("INSERT INTO `advertisers` (`ID`, `Name`, `ServiceType`, `Email`, `Address`, `Phone`, `Slogan`, `WorkingTime`, `IconURL`, `Lat`, `Lng`, `Atit`, `Password`, `Licence`, `CreditCard`) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);;");
            $stmt->bind_param("ssssssssssssss",$name,$serviceType,$email,$adrs,$phone,$slogan,$workingTime,$specificURL,$lat,$lng,$atit,$password,$licence,$cc);

            if($stmt->execute()){
                $stmt->store_result(); 
                //$result=$stmt->bind_result($locationID,$latitude_ret,$longitude_ret,$altitude_ret);
                $resultID=$this->con->insert_id;
                
                $stmt->free_result();
                $stmt->close();
                $resultJSON["return"]=1;
                $resultJSON["userID"]=$resultID;
                return $resultJSON ; 
                //return $resultID;
                
            }else{
                $resultJSON["return"]=-1;
                $resultJSON["userID"]=-1;
                return $resultJSON ;  
            }
        }
    }

    public function LoginAdv($email,$password){
        $pass = md5($password);
        $stmt = $this->con->prepare("SELECT ID FROM advertisers WHERE Email = ?  AND Password = ?");
        $stmt->bind_param("ss",$email,$pass);
        $stmt->execute();
        $stmt->store_result(); 
        $result=$stmt->bind_result($ID);
        $resultID=0;
        while($stmt->fetch()){
            $resultID=$ID;
        }
            /*$stmt->free_result();
                $stmt->close();*/
        
    
        //$this->setOnline($resultID);
        return $resultID;
        //return $stmt->num_rows > 0; 
    }

    public function DeleteAd ($ownerID,$AdID)
    {
        $stmt = $this->con->prepare ("UPDATE `advertisments` SET `Expired` = 1 WHERE `advertisments`.`ID` = ? AND `advertisments`.`OwnerID` = ?");
        $stmt->bind_param("ii",$AdID,$ownerID);
        if($stmt->execute())
        {
            $resultJSON["return"]=1;
            return $resultJSON ; 
            
        }
        else
        {
            $resultJSON["return"]=-1;
            return $resultJSON ;  
        }

    }
    
    public function EditAd1 ($ownerID,$AdID,$title,$desc,$expdate,$img,$imgName)
    {
       $mainURL = 'https://asnasucse18.000webhostapp.com/Android/includes/Pictures/';
        $jpg = '.jpg';
        $specificURL = $mainURL.$imgName.$ownerID.$AdID.$jpg;
        //$password = md5($password);
        $decodedimage = base64_decode("$img");
        file_put_contents("/storage/ssd3/695/4810695/public_html/Android/includes/Pictures/" . $imgName.$ownerID.$AdID . ".jpg", $decodedimage);
        
        $stmt = $this->con->prepare ("UPDATE `advertisments` SET `Title` = ?, `Description` = ?, `ImgURL` = ?, `ExpirationDate` = ? WHERE `advertisments`.`ID` = 9;
");
        $stmt->bind_param("ssssii",$title,$desc, $specificURL,$expdate,$AdID,$ownerID);
        if($stmt->execute())
        {
            $resultJSON["return"]=1;
            return $resultJSON ; 
            
        }
        else
        {
            $resultJSON["return"]=-1;
            return $resultJSON ;  
        }
    }


    public function EditAd ($ownerID,$AdID,$title,$desc,$expdate)
    {
        $stmt = $this->con->prepare ("UPDATE `advertisments` SET `Title` = ?, `Description` = ?, `ExpirationDate` = ? WHERE `advertisments`.`ID` = ? AND `advertisments`.`OwnerID` = ?");
        $stmt->bind_param("sssii",$title,$desc,$expdate,$AdID,$ownerID);
        if($stmt->execute())
        {
            $resultJSON["return"]=1;
            return $resultJSON ; 
            
        }
        else
        {
            $resultJSON["return"]=-1;
            return $resultJSON ;  
        }
    }


    public function getAdvByEmail($email){
        $stmt = $this->con->prepare("SELECT * FROM advertisers WHERE Email = ?");
        $stmt->bind_param("s",$email);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function AddAds ($ownerID,$title,$desc,$expdate,$img,$imgName)
    {
        
        $stmt = $this->con->prepare("INSERT INTO `advertisments` (`ID`, `OwnerID`, `Title`, `Description`, `ImgURL`, `ExpirationDate`) VALUES (NULL, ?, ?, ?, NULL, ?);");
        $stmt->bind_param("isss",$ownerID,$title,$desc,$expdate);
        if($stmt->execute())
        {
            $stmt->store_result(); 
            $AdID=$this->con->insert_id;
            $stmt->free_result();
            $stmt->close();
            $mainURL = 'https://asnasucse18.000webhostapp.com/Android/includes/Pictures/';
            $jpg = '.jpg';
            $specificURL = $mainURL.$imgName.$ownerID.$AdID.$jpg;
            //$password = md5($password);
            $decodedimage = base64_decode("$img");
            file_put_contents("/storage/ssd3/695/4810695/public_html/Android/includes/Pictures/" . $imgName.$ownerID.$AdID . ".jpg", $decodedimage);
            $stmt1 = $this->con->prepare("UPDATE `advertisments` SET `ImgURL` = ? WHERE `advertisments`.`ID` = ?");
            $stmt1->bind_param("si",$specificURL,$AdID);
            $stmt1->execute();
            $resultJSON["return"]=1;
            return $resultJSON ; 
            
        }
        else
        {
            $resultJSON["return"]=-1;
            return $resultJSON ;  
        }

    }
    
    
    
    
    public function FetchAds ($ownerID)
    {
        $stmt = $this->con->prepare("SELECT * FROM `advertisments` WHERE `advertisments`.`OwnerID` = ?");
        $stmt->bind_param("i",$ownerID);
        $stmt->execute();
        $AdsJSON = $stmt->get_result();
        $stmt->close();
        return $AdsJSON;
    }
    
    

    private function isUserExist($userName,$email){
        $stmt = $this->con->prepare("SELECT ID FROM advertisers WHERE Email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute(); 
        $stmt->store_result(); 
        
        $result=$stmt->bind_result($userID);
        $resultID=0;
        while($stmt->fetch()){
            $resultID=$userID;
        }
            $stmt->free_result();
                $stmt->close();
        return $resultID;
        //return $stmt->num_rows > 0; 
    }
}
?>
