<?php 

	class DbOperations{

		public $con; 

		function __construct(){

			require_once dirname(__FILE__) ."/DBConnection.php";

			$db = new DbConnect();

			$this->con = $db->connect();

		}

		/*CRUD -> C -> CREATE */

		public function createUser($personName, $email, $password,$telephone,$address,$token){
            $resultID=$this->isUserExist($personName,$email);
            $resultJSON=array();
			if($resultID){
                $resultJSON["return"]=0;
                $resultJSON["personID"]=$resultID;
				return $resultJSON ; 
			}else{
				$password = md5($password);
			$stmt = $this->con->prepare("INSERT INTO `CarSeller` (`personID`, `personName`, `email`, `password`,`telephone`,`address`,`token`) VALUES (NULL, ?, ?, ?, ?,?,?);");
				$stmt->bind_param("ssssss",$personName,$email,$password,$telephone,$address,$token);

				if($stmt->execute()){
                    $stmt->store_result(); 
                    //$result=$stmt->bind_result($locationID,$latitude_ret,$longitude_ret,$altitude_ret);
                    $resultID=$this->con->insert_id;
                    
                    $stmt->free_result();
                    $stmt->close();
                    $resultJSON["return"]=1;
                    $resultJSON["personID"]=$resultID;
				    return $resultJSON ; 
			        //return $resultID;
					
				}else{
					$resultJSON["return"]=-1;
                    $resultJSON["personID"]=-1;
				    return $resultJSON ;  
				}
			}
		}
		
		
		public function createCar($model, $price,$ownerID){
            //$resultID=$this->isUserExist($personName,$email);
           // $resultJSON=array();
		/*	if($resultID){
                $resultJSON["return"]=0;
                $resultJSON["personID"]=$resultID;
				return $resultJSON ; 
			}*/
			
				//$password = md5($password);
			$stmt = $this->con->prepare("INSERT INTO `CarServices` (`carID`, `model`, `price`,`SoldBoughtFlag`,`ownerID`) VALUES (NULL, ?, ?, 0,?);");
				$stmt->bind_param("sssi",$model,$price,$status,$ownerID);

				if($stmt->execute()){
                    $stmt->store_result(); 
                    //$result=$stmt->bind_result($locationID,$latitude_ret,$longitude_ret,$altitude_ret);
                    $resultID=$this->con->insert_id;
                    
                    $stmt->free_result();
                    $stmt->close();
                    $resultJSON["return"]=1;
                    $resultJSON["carID"]=$resultID;
				    return $resultJSON ; 
			        //return $resultID;
					
				}else{
					$resultJSON["return"]=-1;
                    $resultJSON["carID"]=-1;
				    return $resultJSON ;  
				}
			
		}
		
		
		
		
		
		
		
		public function insertCar($carID,$model, $price,$ownerID){
            
			$stmt = $this->con->prepare("INSERT INTO `CarServices1`(`carID`, `model`, `price`, `SoldBoughtFlag`, `ownerID`) VALUES (?,?,?,0,?);");
				$stmt->bind_param("issi",$carID,$model,$price,$ownerID);

				if($stmt->execute()){
                    $stmt->store_result(); 
                    //$result=$stmt->bind_result($locationID,$latitude_ret,$longitude_ret,$altitude_ret);
                    $resultID=$this->con->insert_id;
                    
                    $stmt->free_result();
                    $stmt->close();
                    $resultJSON["return"]=1;
                    $resultJSON["carID"]=$resultID;
				    return $resultJSON ; 
			        //return $resultID;
					
				}else{
					$resultJSON["return"]=-1;
                    $resultJSON["carID"]=-1;
				    return $resultJSON ;  
				}
			
		}
		
		

		public function userLogin($email,$password){
			$password = md5($password);
			$stmt = $this->con->prepare("SELECT ID FROM drivers WHERE email = ? AND password = ?");
			$stmt->bind_param("ss",$email,$password);
			$stmt->execute();
			$stmt->store_result(); 
			$result=$stmt->bind_result($ID);
            $resultID=0;
            while($stmt->fetch()){
                $resultID=$ID;
            }
                /*$stmt->free_result();
                    $stmt->close();*/
			
		
			//$this->setOnline($resultID);
			return $stmt->num_rows > 0; 
		}
	/*	public function setOnline($id){
		    $stmt = $this->con->prepare("UPDATE drivers SET status='ONLINE' where ID = ? ");
		    $stmt->bind_param("i",$id);
			$stmt->execute();
			return $stmt->num_rows > 0; 
		}*/
       /* public function setOffline($id){
		    $stmt = $this->con->prepare("UPDATE drivers SET status='OFFLINE' where ID = ? ");
		    $stmt->bind_param("i",$id);
			$stmt->execute();
			return $stmt->num_rows > 0; 
		}*/
		
		public function setCBToken($ID,$CBToken){
		    $stmt = $this->con->prepare("UPDATE drivers SET CBToken = ? where ID = ? ;");   
		    $stmt->bind_param("si",$CBToken,$ID);
			$stmt->execute();
			return $stmt->num_rows > 0; 
		}
		
			public function setUpdates($buyerID,$carID){
		    $stmt = $this->con->prepare("UPDATE CarServices1 SET SoldBoughtFlag = 1 where ownerID = ? and carID=?;");   
		    $stmt->bind_param("ii",$buyerID,$carID);
			$stmt->execute();
			return $stmt->num_rows > 0; 
		}
		
		 /* public function setNewOwner($buyerID,$carID){
		    $stmt = $this->con->prepare("UPDATE drives SET carID = ? and driverID= ? ;");   
		    $stmt->bind_param("ii",$buyerID,$carID);
			$stmt->execute();
			return $stmt->num_rows > 0; 
		}*/
		
		
		public function buyCar($carID){
		    $stmt = $this->con->prepare("DELETE FROM CarServices1 where carID = ?");   
		    $stmt->bind_param("i",$carID);
			$stmt->execute();
		//	return $stmt->num_rows > 0; 
		}
		
		public function deleteFromDrives($carID){
		    $stmt = $this->con->prepare("DELETE FROM drives where carID = ?");   
		    $stmt->bind_param("i",$carID);
			$stmt->execute();
			//return $stmt->num_rows > 0; 
		}
		
		public function deleteFromCars($carID){
		    $stmt = $this->con->prepare("DELETE FROM cars where carID = ?");   
		    $stmt->bind_param("i",$carID);
			$stmt->execute();
			//return $stmt->num_rows > 0; 
		}
		
		
		
		
		public function getCBToken($carid){
			$stmt = $this->con->prepare("SELECT CBToken FROM drivers , CarServices1 WHERE carID = ? AND ID=ownerID ");
			//$stmt = $this->con->prepare("SELECT CBToken FROM drivers  WHERE carID = ? AND ID=ownerID ");
			$stmt->bind_param("i",$carid);
			$stmt->execute();
			return $stmt->get_result()->fetch_assoc();
		}
		
			public function getCBToken2($buyerID){
			$stmt = $this->con->prepare("SELECT CBToken FROM drivers WHERE  ID=? ");
			//$stmt = $this->con->prepare("SELECT CBToken FROM drivers  WHERE carID = ? AND ID=ownerID ");
			$stmt->bind_param("i",$buyerID);
			$stmt->execute();
			return $stmt->get_result()->fetch_assoc();
		}
		
		
			public function getToPerson ($token){
			$stmt = $this->con->prepare("SELECT ID FROM drivers WHERE CBToken = ? ");
			$stmt->bind_param("s",$token);
			$stmt->execute();
			return $stmt->get_result()->fetch_assoc();
		}
		
		

		public function getUserByUsername($personName){
			$stmt = $this->con->prepare("SELECT * FROM CarSeller WHERE personName = ?");
			$stmt->bind_param("s",$personName);
			$stmt->execute();
			return $stmt->get_result()->fetch_assoc();
		}
		
		
			public function getCarInfo($personID){
			   $stmt = $this->con->prepare("SELECT * FROM cars,drives WHERE 
			   cars.carID=drives.carID AND driverID=?");
			   $stmt->bind_param("i",$personID);
			   $stmt->execute();
			   return $stmt->get_result()->fetch_assoc();
		}
		
		public function getUserByEmail($email){
			$stmt = $this->con->prepare("SELECT * FROM drivers WHERE email = ?");
			$stmt->bind_param("s",$email);
			$stmt->execute();
			return $stmt->get_result()->fetch_assoc();
		}
		
		public function getCarId($carID){
			$stmt = $this->con->prepare("SELECT * FROM CarServices WHERE carID = ?");
			$stmt->bind_param("i",$id);
			$stmt->execute();
			return $stmt->get_result()->fetch_assoc();
		}
		

		private function isUserExist($personName,$email){
			$stmt = $this->con->prepare("SELECT personID FROM CarSeller WHERE personName = ? OR email = ?");
			$stmt->bind_param("ss", $personName, $email);
			$stmt->execute(); 
			$stmt->store_result(); 
            
            $result=$stmt->bind_result($personName);
            $resultID=0;
            while($stmt->fetch()){
                $resultID=$personID;
            }
                $stmt->free_result();
                    $stmt->close();
			return $resultID;
			//return $stmt->num_rows > 0; 
		}

	}
	
	?>