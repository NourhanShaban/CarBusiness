<?php 

require "../includes/DBConnection.php";

$db = new DbConnect();
$con = $db->connect();

 //creating a query
 $sql = "SELECT serviceCenterID, location, name FROM serviceCenter";
 
 $r = mysqli_query($con,$sql);
 
 $response = array(); 
 
 
 //traversing through all the result 
 
 while($row = mysqli_fetch_array($r)){
    array_push($response,array(
        'id'=>$row['serviceCenterID'],
        'name'=>$row['name'],
        'location'=>$row['location']
    ));
}
 
 echo json_encode($response);

	
?>