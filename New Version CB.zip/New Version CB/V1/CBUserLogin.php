<?php 

require "../includes/CBDbOperations.php";

$response = array(); 

if($_SERVER['REQUEST_METHOD']=='POST'){
	if(isset($_POST['email']) and
	isset($_POST['password'])and isset($_POST['token']) ){
		$db = new DbOperations(); 
		$userID=0;

		if($db->userLogin( $_POST['email'] , $_POST['password'] )){
			$user = $db->getUserByEmail($_POST['email']);
			$response['error'] = false; 
			$response['personID'] = $user['ID'];
			
			

			$response['email'] = $user['email'];
			$response['personName'] = $user['userName'];
			$response['phonenumber'] = $user['phonenumber'];
			
			//$carResponse=$db->getCarId($user['personID']);     /////////////////////
		$tokenResponse=$db->setCBToken($user['ID'],$_POST['token']);
			
			   // $response["carID"]=$carResponse["carID"];
		//	$response["carResponse"]=$carResponse;
			
		}else{
			$response['error'] = true; 
			$response['message'] = "Invalid Email or password";			
		}

	}else{
		$response['error'] = true; 
		$response['message'] = "Required fields are missing";
	}
}

echo json_encode($response);

?>