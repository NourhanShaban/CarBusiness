<?php 

require "../includes/DBConnection.php";

$db = new DbConnect();
$con = $db->connect();

 //creating a query
 if(isset($_POST['ownerID']))
 {
     $ownerID = $_POST['ownerID'];
     $sql = "SELECT ID, Title, Description,ImgURL,ExpirationDate FROM advertisments WHERE advertisments.OwnerID ='$ownerID' AND advertisments.Expired<>1";
     
     $r = mysqli_query($con,$sql);
     //$r->bind_param("i",$_POST['ownerID']);
    $response = array(); 
 
    while($row = mysqli_fetch_array($r)){
    array_push($response,array(
        'title'=>$row['Title'],
        'description'=>$row['Description'],
        'imgURL'=>$row['ImgURL'],
        'expirationDate'=>$row['ExpirationDate'],
        'ID'=>$row['ID']
    ));
}
 
 echo json_encode($response);

 }
 
	
?>