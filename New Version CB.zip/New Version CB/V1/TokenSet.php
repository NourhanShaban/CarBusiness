
<?php 

require "../includes/DbOperations.php";


$response = array(); 

if($_SERVER['REQUEST_METHOD']=='POST'){
	if(
		isset($_POST['userID']) and 
			isset($_POST['token']))
			
		{
		//operate the data further 

		$db = new DbOperations(); 
       
		$result = $db->setToken( 	$_POST['userID'],
									$_POST['token']
								
								);
	
		
		if($result){
			$response['error'] = false; 
			$response['message'] = "token put  successfully";
            $response["token"]=$_POST['token'];
		}else{
			$response['error'] = true; 
			$response['message'] = "Some error occurred please try again";		
            $response["token"]=$_POST['token'];
            $response["userID"]=$_POST["userID"];
            $response["result"]=$result;
		}
       
		
		
		
		
		
	

	}else{
		$response['error'] = true; 
		$response['message'] = "Required fields are missing";
	}
}else{
	$response['error'] = true; 
	$response['message'] = "Invalid Request";
}

echo json_encode($response);


?>