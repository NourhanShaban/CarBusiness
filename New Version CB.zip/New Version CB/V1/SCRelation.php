<?php 
require "../includes/DbOperations.php";
$response = array(); 

if($_SERVER['REQUEST_METHOD']=='POST'){
	if(
		isset($_POST['carID']) and 
			isset($_POST['serviceCenterID']) and 
				isset($_POST['maintenanaceTime'])) 
				
		{
		//operate the data further 

		$db = new DbOperations(); 
        	$userResultJSON = $db->createSCRelation(  
                                               $_POST['carID'],
                                               $_POST['serviceCenterID'], 
                                               $_POST['maintenanaceTime'] 
			                                  );
            

		
		if($userResultJSON["return"] == 1){
			$response['error'] = false; 
			$response['message'] = "Data inserted successfully";
		}elseif($userResultJSON["return"] == -1){
			$response['error'] = true; 
			$response['message'] = "Some error occurred please try again";		
		}elseif($userResultJSON["return"] == 0){
			$response['error'] = true; 
			$response['message'] = "It seems you are already registered, please choose a different email and username";	
		}
		
	

	}else{
		$response['error'] = true; 
		$response['message'] = "Required fields are missing";
	}
}else{
	$response['error'] = true; 
	$response['message'] = "Invalid Request";
}

echo json_encode($response);


?>