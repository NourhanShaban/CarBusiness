
<?php 

require "../includes/CBDbOperations.php";
require "../includes/CarOperations.php";
//require "../includes/CarServices.php";
//require "../includes/CarSeller.php";

$response = array(); 

if($_SERVER['REQUEST_METHOD']=='POST'){
    
	if(     isset($_POST['personName']) and 
			isset($_POST['email']) and 
		    isset($_POST['password']) and
			isset($_POST['telephone']) and
			isset($_POST['address']) and
			isset($_POST['token']))
		{
		//operate the data further 

		$db = new DbOperations(); 
        //$dbcar=new CarOperations();
		$userResultJSON = $db->createUser( 	$_POST['personName'],
									$_POST['email'],
									$_POST['password'],
									$_POST['telephone'],
									$_POST["address"],
									$_POST["token"]
								);
		//$carResultJSON=$dbcar->createCarProfile($_POST['CarModel'],$_POST['CarSerial'])	;
        
        //$result=$resultJSON["return"];
        //$userID=$resultJSON["userID"];
		
		if($userResultJSON["return"] == 1){
			$response['error'] = false; 
			$response['message'] = "User registered successfully";
            $response["personID"]=$userResultJSON["personID"];
		}elseif($userResultJSON["return"] == -1){
			$response['error'] = true; 
			$response['message'] = "Some error occurred please try again";		
            //$response["userID"]=$userID;
		}elseif($userResultJSON["return"] == 0){
			$response['error'] = true; 
			$response['message'] = "It seems you are already registered, please choose a different email and username";	
             $response["personID"]=$userResultJSON["personID"];
		}
       

	}else{
		$response['error'] = true; 
		$response['message'] = "Required fields are missing";
	}
}else{
	$response['error'] = true; 
	$response['message'] = "Invalid Request";
}

echo json_encode($response);


?>