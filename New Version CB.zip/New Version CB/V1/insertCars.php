<?php 


require "../includes/CBDbOperations.php";

$db = new DbOperations();


if($_SERVER['REQUEST_METHOD']=='POST'){
     
	if( isset($_POST['ownerID']) and
	    isset($_POST['price'])){
	    
	    
 
         //creating a query
         $personID=$_POST['ownerID'];
         $price=$_POST['price'];
         // $stmt = $db->con->prepare("SELECT cars.carID,model FROM cars,drives WHERE cars.carID=drives.carID AND driverID=$personID;");
         
         $car = $db->getCarInfo($personID);
         $carID=$car['carID'];
         $model=$car['model'];
         
        
         //executing the query 
        //  $stmt->execute();
         // $stmt->store_result(); 
 
         //binding results to the query 
        // $stmt->bind_result($carID, $model);
           
		
	     
	      
        //$dbcar=new CarOperations();
		$userResultJSON = $db->insertCar($carID,$model,$price,$personID);
									        

        if($userResultJSON["return"] == 1){
			$response['error'] = false; 
			$response['message'] = "Car inserted successfully";
            $response["carID"]=$userResultJSON["carID"];
		}elseif($userResultJSON["return"] == -1){
			$response['error'] = true; 
			$response['message'] = "Some error occurred please try again";		
            //$response["userID"]=$userID;
		}elseif($userResultJSON["return"] == 0){
			$response['error'] = true; 
			$response['message'] = "It seems you are already registered, please choose a different email and username";	
             $response["carID"]=$userResultJSON["carID"];
		}

	}else{
		$response['error'] = true; 
		$response['message'] = "Required fields are missing";
	}
}else{
	$response['error'] = true; 
	$response['message'] = "Invalid Request";
}

echo json_encode($response);


?>