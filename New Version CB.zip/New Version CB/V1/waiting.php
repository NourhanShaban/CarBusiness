<?php
    require "../includes/WaitingOperations.php";
    $response = array(); 

    if($_SERVER['REQUEST_METHOD']=='POST'){
	    if(isset($_POST['problemID'])){
            $db = new WaitingOperations(); 
            
            $resultJSON= $db->getVolunteer($_POST['problemID']);

            if($resultJSON['return'] == 0){
                $response['error'] = false;
                $response['acceptor_found'] = false;
            }
            elseif($resultJSON['return'] == 1){
                $response['error'] = false;
                $response['acceptor_found'] = true;
            }
            $response['acceptor_info'] = $resultJSON["acceptor_info"];

        }else{
            $response['error'] = true; 
            $response['message'] = "Required fields are missing";
        }
    }else{
        $response['error'] = true; 
        $response['message'] = "Invalid Request";
    }
    
    echo json_encode($response);
?>