<?php 

require "../includes/Advoperations.php";

$response = array(); 

if($_SERVER['REQUEST_METHOD']=='POST')
{
	if(
        isset($_POST['ID']) and 
        isset($_POST['title']) and 
        isset($_POST['desc']) and 
		isset($_POST['expirationDate']) and
		isset($_POST['img']) and
        isset($_POST['imgName']))
        {
            $dbAdv = new Advoperations(); 
            $resultJSON = $dbAdv->AddAds($_POST['ID'],$_POST['title'], $_POST['desc'],$_POST['expirationDate'],$_POST['img'],$_POST['imgName']);
            if($resultJSON["return"] == 1)
            {
                $response['error'] = false; 
                $response['message'] = "Advertisement added successfully";
                //$response['AdID'] =  $resultJSON["AdID"];
            }   

            elseif($resultJSON["return"] == -1)
            {
                $response['error'] = true; 
                $response['message'] = "Some error occurred please try again";		
            }


        }

        else
        {
            $response['error'] = true; 
            $response['message'] = "Required fields are missing";
        }
    }
    else
    {
        $response['error'] = true; 
        $response['message'] = "Invalid Request";
    }
    
    echo json_encode($response);
    // echo "DONE";
    
    ?>
}
                