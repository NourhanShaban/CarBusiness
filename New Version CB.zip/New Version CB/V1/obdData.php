<?php 

require "../includes/DbOperations.php";


$response = array(); 

if($_SERVER['REQUEST_METHOD']=='GET'){
	if( 
		    isset($_GET['VehicleIdentificationNumber']) and 
			isset($_GET['ControlModulePowerSupply']) and 
            isset($_GET['TimingAdvance']) and
            isset($_GET['CommandEquivalenceRatio'])and
            isset($_GET['DistancetraveledwithMILon'])and
            isset($_GET['TimerunwithMILon']) and 
            isset($_GET['Distancesincecodescleared']) and 
			isset($_GET['Timesincetroublecodescleared']) and 
            isset($_GET['EngineRPM']) and
            isset($_GET['EngineRuntime'])and
            isset($_GET['Engineoiltemperature'])and
            isset($_GET['ThrottlePosition']) and
            isset($_GET['EngineLoad']) and 
			isset($_GET['Absoluteload']) and 
            isset($_GET['MassAirFlow']) and
            isset($_GET['FuelInjectionTiming'])and
            isset($_GET['RelativeAccPedalPos'])and
            isset($_GET['FuelLevel']) and 
            isset($_GET['FuelType']) and 
			isset($_GET['FuelConsumptionRate']) and 
            isset($_GET['AirFuelRatio']) and
            isset($_GET['LongTermFuelTrimBank1'])and
            isset($_GET['LongTermFuelTrimBank2'])and
            isset($_GET['ShortTermFuelTrimBank1']) and
            isset($_GET['ShortTermFuelTrimBank2'])and
            isset($_GET['WidebandAirFuelRatio']) and
            isset($_GET['FuelPressure']) and 
			isset($_GET['FuelRailPressure']) and 
            isset($_GET['BarometricPressure']) and
            isset($_GET['IntakeManifoldPressure'])and
            isset($_GET['Absoluteevapsystemvaporpressure'])and
            isset($_GET['Evaporationsystemvaporpressure']) and 
            isset($_GET['EngineCoolantTemperature']) and 
			isset($_GET['AirIntakeTemperature']) and 
            isset($_GET['CatalystTemperatureBank1Sensor1']) and
            isset($_GET['CatalystTemperatureBank2Sensor1'])and
            isset($_GET['CatalystTemperatureBank1Sensor2'])and
            isset($_GET['CatalystTemperatureBank2Sensor2']) and
            isset($_GET['AmbientAirTemperature']) and
            isset($_GET['VehicleSpeed']) and 
			isset($_GET['hypridBatteryremainlife']) and 
            isset($_GET['ActualEnginePercentTorque']) and
            isset($_GET['DriversdemandengineTourque'])and
            isset($_GET['EnginerefrenceTourque'])and
            isset($_GET['EvaporativePurge']) and 
            isset($_GET['CommandedEGR']) and 
			isset($_GET['EGRerror']) and 
            isset($_GET['EthanolPercentage']) and
            isset($_GET['DiagnosticTroubleCodes'])and
            isset($_GET['TroubleCodes'])and
            isset($_GET['PendingTroubleCodes']) and
            isset($_GET['PermanentTroubleCodes']))
		{
		//operate the data further 

		$db = new DbOperations(); 
		$userResultJSON = $db->insertOBDData(  $_GET['VehicleIdentificationNumber'] , 
			                                   $_GET['ControlModulePowerSupply'] ,  
                                               $_GET['TimingAdvance'] ,
                                               $_GET['CommandEquivalenceRatio'] ,
                                               $_GET['DistancetraveledwithMILon'] ,
                                               $_GET['TimerunwithMILon'] ,
                                               $_GET['Distancesincecodescleared'] , 
			                                   $_GET['Timesincetroublecodescleared'],
                                               $_GET['EngineRPM'],                                         
                                               $_GET['EngineRuntime'],
                                               $_GET['Engineoiltemperature'],
                                               $_GET['ThrottlePosition'],
                                               $_GET['EngineLoad'], 
			                                   $_GET['Absoluteload'], 
                                               $_GET['MassAirFlow'],
                                               $_GET['FuelInjectionTiming'],
                                               $_GET['RelativeAccPedalPos'],
                                               $_GET['FuelLevel'], 
                                               $_GET['FuelType'],           
			                                   $_GET['FuelConsumptionRate'], 
                                               $_GET['AirFuelRatio'],
                                               $_GET['LongTermFuelTrimBank1'],
                                               $_GET['LongTermFuelTrimBank2'],
                                               $_GET['ShortTermFuelTrimBank1'],
                                               $_GET['ShortTermFuelTrimBank2'],
                                               $_GET['WidebandAirFuelRatio'],
                                               $_GET['FuelPressure'], 
			                                   $_GET['FuelRailPressure'], 
                                               $_GET['BarometricPressure'],
                                               $_GET['IntakeManifoldPressure'],
                                               $_GET['Absoluteevapsystemvaporpressure'],
                                               $_GET['Evaporationsystemvaporpressure'], 
                                               $_GET['EngineCoolantTemperature'], 
			                                   $_GET['AirIntakeTemperature'], 
                                               $_GET['CatalystTemperatureBank1Sensor1'],
                                               $_GET['CatalystTemperatureBank2Sensor1'],
                                               $_GET['CatalystTemperatureBank1Sensor2'],
                                               $_GET['CatalystTemperatureBank2Sensor2'],
                                               $_GET['AmbientAirTemperature'], 
                                               $_GET['VehicleSpeed'],
                                               $_GET['hypridBatteryremainlife'],
                                               $_GET['ActualEnginePercentTorque'],
                                               $_GET['DriversdemandengineTourque'],
                                               $_GET['EnginerefrenceTourque'],
                                               $_GET['EvaporativePurge'],
                                               $_GET['CommandedEGR'], 
			                                   $_GET['EGRerror'], 
                                               $_GET['EthanolPercentage'],
                                               $_GET['DiagnosticTroubleCodes'],
                                               $_GET['TroubleCodes'],
                                               $_GET['PendingTroubleCodes'], 
                                               $_GET['PermanentTroubleCodes'] 
			                                  );
            

		
		if($userResultJSON["return"] == 1){
			$response['error'] = false; 
			$response['message'] = "Data inserted successfully";
            $response["OBDID"]=$userResultJSON["OBDID"];
		}elseif($userResultJSON["return"] == -1){
			$response['error'] = true; 
			$response['message'] = "Some error occurred please try again";		
		}elseif($userResultJSON["return"] == 0){
			$response['error'] = true; 
			$response['message'] = "It seems you are already registered, please choose a different email and username";	
             $response["OBDID"]=$userResultJSON["OBDID"];
		}
		
	

	}else{
		$response['error'] = true; 
		$response['message'] = "Required fields are missing";
	}
}else{
	$response['error'] = true; 
	$response['message'] = "Invalid Request";
}

echo json_encode($response);


?>