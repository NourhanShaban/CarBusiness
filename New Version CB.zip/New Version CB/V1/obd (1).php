<?php 

require "../includes/DbOperations.php";


$response = array(); 

if($_SERVER['REQUEST_METHOD']=='POST'){
	if( 
		    isset($_POST['VehicleIdentificationNumberVIN']) and 
			isset($_POST['ControlModulePowerSupply']) and 
            isset($_POST['TimingAdvance']) and
            isset($_POST['CommandEquivalenceRatio'])and
            isset($_POST['DistancetraveledwithMILon'])and
            isset($_POST['TimerunwithMILon']) and 
            isset($_POST['Distancesincecodescleared']) and 
			isset($_POST['Timesincetroublecodescleared']) and 
            isset($_POST['EngineRPM']) and
            isset($_POST['EngineRuntime'])and
            isset($_POST['Engineoiltemperature'])and
            isset($_POST['ThrottlePosition']) and
            isset($_POST['EngineLoad']) and 
			isset($_POST['Absoluteload']) and 
            isset($_POST['MassAirFlow']) and
            isset($_POST['FuelInjectionTiming'])and
            isset($_POST['RelativeAccPedalPos'])and
            isset($_POST['FuelLevel']) and 
            isset($_POST['FuelType']) and 
			isset($_POST['FuelConsumptionRate']) and 
            isset($_POST['AirFuelRatio']) and
            isset($_POST['LongTermFuelTrimBank1'])and
            isset($_POST['LongTermFuelTrimBank2'])and
            isset($_POST['ShortTermFuelTrimBank1']) and
            isset($_POST['ShortTermFuelTrimBank2'])and
            isset($_POST['WidebandAirFuelRatio']) and
            isset($_POST['FuelPressure']) and 
			isset($_POST['FuelRailPressure']) and 
            isset($_POST['BarometricPressure']) and
            isset($_POST['IntakeManifoldPressure'])and
            isset($_POST['Absoluteevapsystemvaporpressure'])and
            isset($_POST['Evaporationsystemvaporpressure']) and 
            isset($_POST['EngineCoolantTemperature']) and 
			isset($_POST['AirIntakeTemperature']) and 
            isset($_POST['CatalystTemperatureBank1Sensor1']) and
            isset($_POST['CatalystTemperatureBank2Sensor1'])and
            isset($_POST['CatalystTemperatureBank1Sensor2'])and
            isset($_POST['CatalystTemperatureBank2Sensor2']) and
            isset($_POST['AmbientAirTemperature']) and
            isset($_POST['VehicleSpeed']) and 
			isset($_POST['hypridBatteryremainlife']) and 
            isset($_POST['ActualEnginePercentTorque']) and
            isset($_POST['DriversdemandengineTourque'])and
            isset($_POST['EnginerefrenceTourque'])and
            isset($_POST['EvaporativePurge']) and 
            isset($_POST['CommandedEGR']) and 
			isset($_POST['EGRerror']) and 
            isset($_POST['EthanolPercentage']) and
            isset($_POST['DiagnosticTroubleCodes'])and
            isset($_POST['TroubleCodes'])and
            isset($_POST['PendingTroubleCodes']) and
            isset($_POST['PermanentTroubleCodes']))
		{
		//operate the data further 

		$db = new DbOperations(); 
		$userResultJSON = $db->insertOBDData(  $_POST['VehicleIdentificationNumberVIN'] , 
			                                   $_POST['ControlModulePowerSupply'] ,  
                                               $_POST['TimingAdvance'] ,
                                               $_POST['CommandEquivalenceRatio'] ,
                                               $_POST['DistancetraveledwithMILon'] ,
                                               $_POST['TimerunwithMILon'] ,
                                               $_POST['Distancesincecodescleared'] , 
			                                   $_POST['Timesincetroublecodescleared'],
                                               $_POST['EngineRPM'],                                         
                                               $_POST['EngineRuntime'],
                                               $_POST['Engineoiltemperature'],
                                               $_POST['ThrottlePosition'],
                                               $_POST['EngineLoad'], 
			                                   $_POST['Absoluteload'], 
                                               $_POST['MassAirFlow'],
                                               $_POST['FuelInjectionTiming'],
                                               $_POST['RelativeAccPedalPos'],
                                               $_POST['FuelLevel'], 
                                               $_POST['FuelType'],           
			                                   $_POST['FuelConsumptionRate'], 
                                               $_POST['AirFuelRatio'],
                                               $_POST['LongTermFuelTrimBank1'],
                                               $_POST['LongTermFuelTrimBank2'],
                                               $_POST['ShortTermFuelTrimBank1'],
                                               $_POST['ShortTermFuelTrimBank2'],
                                               $_POST['WidebandAirFuelRatio'],
                                               $_POST['FuelPressure'], 
			                                   $_POST['FuelRailPressure'], 
                                               $_POST['BarometricPressure'],
                                               $_POST['IntakeManifoldPressure'],
                                               $_POST['Absoluteevapsystemvaporpressure'],
                                               $_POST['Evaporationsystemvaporpressure'], 
                                               $_POST['EngineCoolantTemperature'], 
			                                   $_POST['AirIntakeTemperature'], 
                                               $_POST['CatalystTemperatureBank1Sensor1'],
                                               $_POST['CatalystTemperatureBank2Sensor1'],
                                               $_POST['CatalystTemperatureBank1Sensor2'],
                                               $_POST['CatalystTemperatureBank2Sensor2'],
                                               $_POST['AmbientAirTemperature'], 
                                               $_POST['VehicleSpeed'],
                                               $_POST['hypridBatteryremainlife'],
                                               $_POST['ActualEnginePercentTorque'],
                                               $_POST['DriversdemandengineTourque'],
                                               $_POST['EnginerefrenceTourque'],
                                               $_POST['EvaporativePurge'],
                                               $_POST['CommandedEGR'], 
			                                   $_POST['EGRerror'], 
                                               $_POST['EthanolPercentage'],
                                               $_POST['DiagnosticTroubleCodes'],
                                               $_POST['TroubleCodes'],
                                               $_POST['PendingTroubleCodes'], 
                                               $_POST['PermanentTroubleCodes'] 
			                                  );
            

		
		if($userResultJSON["return"] == 1){
			$response['error'] = false; 
			$response['message'] = "Data inserted successfully";
            $response["Oid"]=$userResultJSON["Oid"];
		}elseif($userResultJSON["return"] == -1){
			$response['error'] = true; 
			$response['message'] = "Some error occurred please try again";		
		}elseif($userResultJSON["return"] == 0){
			$response['error'] = true; 
			$response['message'] = "It seems you are already registered, please choose a different email and username";	
             $response["Oid"]=$userResultJSON["Oid"];
		}
		
	

	}else{
		$response['error'] = true; 
		$response['message'] = "Required fields are missing";
	}
}else{
	$response['error'] = true; 
	$response['message'] = "Invalid Request";
}

echo json_encode($response);


?>