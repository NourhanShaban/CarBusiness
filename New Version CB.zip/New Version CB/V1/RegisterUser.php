
<?php 

require "../includes/DbOperations.php";
require "../includes/CarOperations.php";
require "../includes/drives.php";

$response = array(); 

if($_SERVER['REQUEST_METHOD']=='POST'){
	if(
		isset($_POST['userName']) and 
			isset($_POST['email']) and 
				isset($_POST['password']) and
				isset($_POST['phonenumber']) and
				isset($_POST['CarModel'])and
				isset($_POST['CarSerial']) and
				isset($_POST["token"]))
		{
		//operate the data further 

		$db = new DbOperations(); 
        $dbcar=new CarOperations();
		$userResultJSON = $db->createUser( 	$_POST['userName'],
									$_POST['email'],
									$_POST['password'],
									$_POST['phonenumber'],
									$_POST["token"]
								);
		$carResultJSON=$dbcar->createCarProfile($_POST['CarModel'],$_POST['CarSerial'])	;
        
        //$result=$resultJSON["return"];
        //$userID=$resultJSON["userID"];
		
		if($userResultJSON["return"] == 1){
			$response['error'] = false; 
			$response['message'] = "User registered successfully";
            $response["userID"]=$userResultJSON["userID"];
		}elseif($userResultJSON["return"] == -1){
			$response['error'] = true; 
			$response['message'] = "Some error occurred please try again";		
            //$response["userID"]=$userID;
		}elseif($userResultJSON["return"] == 0){
			$response['error'] = true; 
			$response['message'] = "It seems you are already registered, please choose a different email and username";	
             $response["userID"]=$userResultJSON["userID"];
		}
       
		
		
		
		
		if($carResultJSON["return"]==1){
		    	$response['errorCar'] = false; 
			$response['messageCar'] = "Car registered successfully";
			$response["carID"]=$carResultJSON["carID"];
		    
		}elseif($carResultJSON["return"]==-1){
		    	$response['errorCar'] = true; 
			$response['messageCar'] = "Some error occurred in car please try again";
			$response['extraInfo']=$_POST['CarModel'] . " ". $_POST['CarSerial'];
			$response["carResponse"]=$carResultJSON;
		    
		}elseif($carResultJSON["return"]==0){
            $response['errorCar'] = true; 
			$response['messageCar'] = "It seems that your car is already registered";
				$response["carID"]=$carResultJSON["carID"];
        }
         if(($userResultJSON["return"] == 1 )&&
        ($carResultJSON["return"]==1 )){
            //have userID go for inserting in drives
             $userID=$userResultJSON["userID"];
             $carID=$carResultJSON["carID"];
             $relationResult=createCarDriverRelation($userID,$carID);
             if($relationResult){
                 $response["errorRelation"]=true;
                 $response["messageRelation"]="car-driver relation created sucessfully";
             }else{
                  $response["errorRelation"]=false;
                 $response["messageRelation"]="It seems that your car-driver relation has error";
             }
             
             
        }
		
	

	}else{
		$response['error'] = true; 
		$response['message'] = "Required fields are missing";
	}
}else{
	$response['error'] = true; 
	$response['message'] = "Invalid Request";
}

echo json_encode($response);


?>