<?php 

require "../includes/Advoperations.php";

$response = array(); 

if($_SERVER['REQUEST_METHOD']=='POST')
{
    if(
        isset($_POST['ownerID']) and 
        isset($_POST['advID']) and 
        isset($_POST['delete'])
        and $_POST['delete'] == 1)
    {
        
        $dbAdv = new Advoperations(); 
        $resultJSON = $dbAdv->DeleteAd($_POST['ownerID'],$_POST['advID']);
        if($resultJSON["return"] == 1)
            {
                $response['error'] = false; 
                $response['message'] = "Advertisement deleted successfully";
                //$response['AdID'] =  $resultJSON["AdID"];
            }   

            elseif($resultJSON["return"] == -1)
            {
                $response['error'] = true; 
                $response['message'] = "Some error occurred while deleting advertisement, please try again";		
            }
        

    }
	else if(
        isset($_POST['ownerID']) and 
        isset($_POST['advID']) and 
        isset($_POST['title']) and 
        isset($_POST['desc']) and 
		isset($_POST['expirationDate']))
		//isset($_POST['img']) and
        //isset($_POST['imgName']))
        {
            $dbAdv = new Advoperations(); 
            $resultJSON = $dbAdv->EditAd($_POST['ownerID'],$_POST['advID'],$_POST['title'], $_POST['desc'],$_POST['expirationDate']);
            if($resultJSON["return"] == 1)
            {
                $response['error'] = false; 
                $response['message'] = "Advertisement edited successfully";
                //$response['AdID'] =  $resultJSON["AdID"];
            }   

            elseif($resultJSON["return"] == -1)
            {
                $response['error'] = true; 
                $response['message'] = "Some error occurred while editing advertisement, please try again";		
            }


        }
        
        else if(
        isset($_POST['ownerID']) and 
        isset($_POST['advID']) and 
        isset($_POST['title']) and 
        isset($_POST['desc']) and 
		isset($_POST['expirationDate']) and
		isset($_POST['img']) and
        isset($_POST['imgName']))
        {
            $dbAdv = new Advoperations(); 
            $resultJSON = $dbAdv->EditAd1($_POST['ownerID'],$_POST['advID'],$_POST['title'], $_POST['desc'],$_POST['expirationDate'],$_POST['img'],$_POST['imgName']);
            if($resultJSON["return"] == 1)
            {
                $response['error'] = false; 
                $response['message'] = "Advertisement edited successfully";
                //$response['AdID'] =  $resultJSON["AdID"];
            }   

            elseif($resultJSON["return"] == -1)
            {
                $response['error'] = true; 
                $response['message'] = "Some error occurred while editing advertisement, please try again";		
            }


        }
        
        
        

        else
        {
            $response['error'] = true; 
            $response['message'] = "Required fields are missing";
        }



}

    else
    {
        $response['error'] = true; 
        $response['message'] = "Invalid Request";
    }
    
    echo json_encode($response);
    
    
    ?>