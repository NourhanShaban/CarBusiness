<?php 

require "../includes/Advoperations.php";

$response = array(); 

if($_SERVER['REQUEST_METHOD']=='POST'){
	if(
        isset($_POST['name']) and 
        isset($_POST['slogan']) and 
			isset($_POST['serviceType']) and 
				isset($_POST['adrs']) and
				isset($_POST['workingTime']) and
				isset($_POST['phone'])and
				isset($_POST['email']) and
                isset($_POST["licence"]) and
                isset($_POST["icon"]) and
               isset($_POST["iconName"]) and
                isset($_POST["lat"]) and
                isset($_POST["lng"]) and
                isset($_POST["atit"])and
                isset($_POST["creditCard"]) and
                isset($_POST["password"]))

                {
                    //operate the data further 
            
                    $dbAdv = new Advoperations(); 
                    
                    $userResultJSON = $dbAdv->createAdvertiser($_POST['name'],
                    $_POST['slogan'],
                        $_POST['serviceType'],
                            $_POST['adrs'],
                            $_POST['workingTime'],
                            $_POST['phone'],
                            $_POST['email'],
                            $_POST["licence"],
                            $_POST["icon"],
                            $_POST["iconName"],
                            $_POST["lat"],
                            $_POST["lng"],
                            $_POST["atit"],
                            $_POST["password"],
                            $_POST["creditCard"]);
                   
                    if($userResultJSON["return"] == 1){
                        $mainURL = 'https://asnasucse18.000webhostapp.com/Android/includes/Pictures/';
                        $jpg = '.jpg';
                        $specificURL = $mainURL.$_POST["iconName"].$_POST['email'].$jpg;
                        $response['error'] = false; 
                        $response['message'] = "User registered successfully";
                        $response["ID"]=$userResultJSON["userID"];
                        $response['name'] =$_POST['name'] ;
                        $response['slogan'] =$_POST['slogan'] ;
                        $response['serviceType'] =$_POST['serviceType'] ;
                        $response['adrs'] = $_POST['adrs'];
                        $response['workingTime'] =$_POST['workingTime'] ;
                        $response['phone'] = $_POST['phone'];
                        $response['email'] = $_POST['email'];
                        $response['licence'] = $_POST['licence'];
                        $response['iconURL'] = $specificURL;
                        $response['lng'] = $_POST['lng'];
                        $response['lat'] = $_POST['lat'];
                        $response['atit'] = $_POST['atit'];
                        $response['creditCard'] = $_POST['creditCard'];
                    }elseif($userResultJSON["return"] == -1){
                        $response['error'] = true; 
                        $response['message'] = "Some error occurred please try again";		
                    }elseif($userResultJSON["return"] == 0){
                        $response['error'] = true; 
                        $response['message'] = "It seems you are already registered, please choose a different email and username";	
                         $response["userID"]=$userResultJSON["userID"];
                    }
                   
                   
                }else{
                    $response['error'] = true; 
                    $response['message'] = "Required fields are missing";
                }
            }else{
                $response['error'] = true; 
                $response['message'] = "Invalid Request";
            }
            
            echo json_encode($response);
            
            
            ?>