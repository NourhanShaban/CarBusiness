<?php 

require "../includes/Advoperations.php";

$response = array(); 

if($_SERVER['REQUEST_METHOD']=='POST'){
	if(isset($_POST['email']) and isset($_POST['password']))
	{

		$db = new Advoperations(); 
		$userID=0;

		if(($db->LoginAdv( $_POST['email'] , $_POST['password'])))
		{
			$user = $db->getAdvByEmail($_POST['email']);
			$response['error'] = false; 
			$response['ID'] = $user['ID'];
            $response['name'] =$user['Name'] ;
            $response['slogan'] =$user['Slogan'] ;
            $response['serviceType'] =$user['ServiceType'] ;
            $response['adrs'] =$user['Address'];
            $response['workingTime'] =$user['WorkingTime'] ;
            $response['phone'] = $user['Phone'];
            $response['email'] =$user['Email'];
            $response['licence'] = $user['Licence'];
            $response['iconURL'] = $user['IconURL'];
            $response['lng'] = $user['Lng'];
            $response['lat'] =$user['Lat'];
            $response['atit'] = $user['Atit'];
                        
            
			
			//$carResponse=$db->getCarId($user['ID']);
			//$tokenResponse=$db->setToken($user['ID'],$_POST['token']);
			
			  //  $response["carID"]=$carResponse["carID"];
			//$response["carResponse"]=$carResponse;
			
		}
		else
		{
			$response['error'] = true; 
			$response['message'] = "Invalid username or password";			
        }
    }

	
	else
	{
		$response['error'] = true; 
		$response['message'] = "Required fields are missing";
	}
}

else{
	$response['error'] = true; 
	$response['message'] = "Invalid Request";
}


echo json_encode($response);

?>