
<?php 

require "../includes/LocationOperations.php";

$response = array(); 

if($_SERVER['REQUEST_METHOD']=='POST'){
	if(
		isset($_POST['latitude']) and 
			isset($_POST['longitude']) and 
				isset($_POST['altitude']) and
            isset($_POST["userID"]) and
            isset($_POST["carID"]) and
            isset($_POST["locationTime"]))
		{
		//operate the data further 

		$db = new LocationOperations(); 
        
		$result = $db->createLocation( 	$_POST['latitude'],
									$_POST['longitude'],
									$_POST['altitude']
   							 );
        $resultRelation=$db ->bindLocationDriverCar($result,
                                                    $_POST["userID"],
                                                    $_POST["carID"],
                                                    $_POST["locationTime"]);
   								 
   	   
        
		
		if($result == -1){
			$response['error'] = true; 
			 
            
			$response['message'] = "Some error occurred please try again";
		}elseif($result>0){
			$response['error'] = false; 
            
			$response['message'] = "Location set with ID = ".(string)$result;			
		}elseif($result == 0){
			$response['error'] = true; 
            
			$response['message'] = "ID = 0 ";						
		}
		if($resultRelation==1 ){
            $response['errorLocationDriverCar'] = false; 
            
			$response['messageLocationDriverCar'] = "LocationDriverCar data inserted sucessfully";		
        }else{
            $response['errorLocationDriverCar'] = true; 
            
			$response['messageLocationDriverCar'] = "It seems LocationDriverCar data has error";
        }
		
		
		
	}else{
		$response['error'] = true; 
		$response['message'] = "Required fields are missing";
	}
}else{
	$response['error'] = true; 
	$response['message'] = "Invalid Request";
}

echo json_encode($response);


?>