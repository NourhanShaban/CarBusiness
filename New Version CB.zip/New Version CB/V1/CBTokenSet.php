<?php 

require "../includes/CBDbOperations.php";


$response = array(); 

if($_SERVER['REQUEST_METHOD']=='GET'){
	if(
		isset($_GET['personID']) and 
			isset($_GET['token']))
			
		{
		//operate the data further 

		$db = new DbOperations(); 
       
		$result = $db->setToken( 	$_GET['personID'],
									$_GET['token']
								
								);
	
		
		if($result){
			$response['error'] = false; 
			$response['message'] = "token put  successfully";
            $response["token"]=$_GET['token'];
		}else{
			$response['error'] = true; 
			$response['message'] = "Some error occurred please try again";		
            $response["token"]=$_GET['token'];
            $response["personID"]=$_GET["personID"];
            $response["result"]=$result;
		}
       
		
		
		
		
		
	

	}else{
		$response['error'] = true; 
		$response['message'] = "Required fields are missing";
	}
}else{
	$response['error'] = true; 
	$response['message'] = "Invalid Request";
}

echo json_encode($response);


?>